module CompatResource
  VERSION = '12.5.23'
end
